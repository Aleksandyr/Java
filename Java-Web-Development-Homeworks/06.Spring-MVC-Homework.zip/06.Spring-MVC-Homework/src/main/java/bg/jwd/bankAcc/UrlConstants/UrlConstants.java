package bg.jwd.bankAcc.UrlConstants;

public class UrlConstants {
	public final static String USER_ACCOUNT_URL = "";
}
